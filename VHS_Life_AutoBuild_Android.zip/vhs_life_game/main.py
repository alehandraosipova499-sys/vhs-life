from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.graphics import Color, Rectangle, Ellipse, Line
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.metrics import dp
from random import choice

ROOMS = [
    ("Гостиная", (0.96, 0.83, 0.66)),
    ("Кухня", (0.78, 0.88, 0.78)),
    ("Спальня", (0.78, 0.82, 0.96)),
    ("Ванная", (0.72, 0.89, 0.92)),
]
OBJECTS = ["Диван", "Стол", "Растение", "Лампа", "Кровать", "Шкаф", "Игрушка"]

class World(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.room_index = 0
        self.avatar_x = .5
        self.avatar_y = .34
        self.message = "Привет! Нажми на предмет, чтобы взаимодействовать."
        self.selected = None
        self.bind(pos=self.redraw, size=self.redraw)
        Clock.schedule_once(lambda dt: self.redraw(), 0)

    def redraw(self, *args):
        self.canvas.clear()
        w, h = self.width, self.height
        if w <= 0 or h <= 0:
            return
        room_name, bg = ROOMS[self.room_index]
        with self.canvas:
            Color(*bg)
            Rectangle(pos=self.pos, size=self.size)
            Color(0.91, 0.77, 0.60)
            Rectangle(pos=(self.x, self.y), size=(w, h*.18))
            Color(0.66, 0.48, 0.34)
            Rectangle(pos=(self.x, self.y+h*.17), size=(w, dp(5)))
            # window
            Color(.70, .88, .98)
            Rectangle(pos=(self.x+w*.70, self.y+h*.56), size=(w*.20, h*.24))
            Color(1,1,1)
            Line(rectangle=(self.x+w*.70, self.y+h*.56, w*.20, h*.24), width=2)
            Line(points=[self.x+w*.80, self.y+h*.56, self.x+w*.80, self.y+h*.80], width=2)
            Line(points=[self.x+w*.70, self.y+h*.68, self.x+w*.90, self.y+h*.68], width=2)
            # rug
            Color(.91, .70, .73)
            Ellipse(pos=(self.x+w*.20, self.y+h*.19), size=(w*.43, h*.13))
            # furniture changes by room
            if self.room_index == 0:
                Color(.35,.55,.72); Rectangle(pos=(self.x+w*.12,self.y+h*.34),size=(w*.34,h*.22))
                Color(.95,.85,.70); Rectangle(pos=(self.x+w*.15,self.y+h*.50),size=(w*.28,h*.06))
                Color(.45,.30,.20); Rectangle(pos=(self.x+w*.52,self.y+h*.30),size=(w*.12,h*.18))
            elif self.room_index == 1:
                Color(.96,.96,.92); Rectangle(pos=(self.x+w*.10,self.y+h*.31),size=(w*.28,h*.22))
                Color(.50,.70,.62); Rectangle(pos=(self.x+w*.46,self.y+h*.31),size=(w*.28,h*.08))
                Color(.85,.65,.40); Rectangle(pos=(self.x+w*.49,self.y+h*.39),size=(w*.22,h*.04))
            elif self.room_index == 2:
                Color(.55,.40,.68); Rectangle(pos=(self.x+w*.12,self.y+h*.30),size=(w*.42,h*.25))
                Color(.98,.92,.88); Rectangle(pos=(self.x+w*.15,self.y+h*.49),size=(w*.36,h*.06))
                Color(.48,.34,.24); Rectangle(pos=(self.x+w*.62,self.y+h*.29),size=(w*.13,h*.25))
            else:
                Color(.95,.98,.99); Rectangle(pos=(self.x+w*.12,self.y+h*.31),size=(w*.30,h*.25))
                Color(.38,.68,.78); Ellipse(pos=(self.x+w*.53,self.y+h*.31),size=(w*.26,h*.18))
            # avatar
            ax, ay = self.x+w*self.avatar_x, self.y+h*self.avatar_y
            Color(.30,.22,.18); Ellipse(pos=(ax-w*.035, ay+h*.08), size=(w*.07,h*.09))
            Color(.98,.75,.56); Ellipse(pos=(ax-w*.027, ay+h*.12), size=(w*.054,h*.07))
            Color(.95,.42,.48); Rectangle(pos=(ax-w*.035, ay), size=(w*.07,h*.12))
            Color(.22,.22,.28)
            Line(points=[ax-w*.02,ay,ax-w*.03,ay-h*.06],width=3)
            Line(points=[ax+w*.02,ay,ax+w*.03,ay-h*.06],width=3)

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return super().on_touch_down(touch)
        self.avatar_x = max(.08, min(.92, (touch.x-self.x)/self.width))
        self.avatar_y = max(.24, min(.46, (touch.y-self.y)/self.height))
        self.message = choice(["Персонаж переместился!", "Как уютно здесь!", "Что будем делать дальше?"])
        self.redraw()
        return True

class VHSLifeApp(App):
    def build(self):
        Window.clearcolor = (0.95, 0.93, 0.89, 1)
        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        header = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
        self.room_label = Label(text="VHS LIFE", bold=True, font_size="22sp", color=(.22,.22,.30,1))
        header.add_widget(self.room_label)
        root.add_widget(header)

        self.world = World()
        root.add_widget(self.world)

        self.status = Label(text=self.world.message, size_hint_y=None, height=dp(34),
                            color=(.20,.20,.25,1), font_size="14sp")
        root.add_widget(self.status)

        rooms = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(5))
        for i, (name, _) in enumerate(ROOMS):
            b = Button(text=name, font_size="12sp", background_normal="",
                       background_color=(.45,.55,.72,1), color=(1,1,1,1))
            b.bind(on_release=lambda btn, idx=i: self.change_room(idx))
            rooms.add_widget(b)
        root.add_widget(rooms)

        actions = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(5))
        for name in ["Переодеться", "Поесть", "Играть"]:
            b = Button(text=name, font_size="13sp", background_normal="",
                       background_color=(.85,.56,.62,1), color=(1,1,1,1))
            b.bind(on_release=lambda btn, action=name: self.do_action(action))
            actions.add_widget(b)
        root.add_widget(actions)
        return root

    def change_room(self, idx):
        self.world.room_index = idx
        self.world.message = f"Ты перешёл(ла): {ROOMS[idx][0]}"
        self.room_label.text = ROOMS[idx][0].upper()
        self.status.text = self.world.message
        self.world.redraw()

    def do_action(self, action):
        messages = {
            "Переодеться": "Новый образ готов! (в этой демо-версии — смена настроения)",
            "Поесть": "Ням! Персонаж перекусил.",
            "Играть": "Время играть! Выбери комнату и исследуй её.",
        }
        self.status.text = messages[action]
        self.world.message = messages[action]

if __name__ == "__main__":
    VHSLifeApp().run()
